#!/bin/sh
PERCENT=$1
USER=$2
MAILDOMAIN=`/bin/cat /etc/mailname`
cat << EOF | /usr/lib/dovecot/dovecot-lda -d $USER -o "plugin/quota=maildir:User quota:noenforcing"
From: postmaster@$MAILDOMAIN
Subject: Advertencia de cuota por $PERCENT% de uso.

Su buzon solo puede almacenar una cantidad limitada de correo. Actualmente esta al $PERCENT% de su capacidad. Si usted alcanza el 100%, entonces los nuevos correos no podrán ser almacenados.
Gracias por su comprensión.
EOF

